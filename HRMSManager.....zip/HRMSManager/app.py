import os
import logging
import pymysql

# Make PyMySQL compatible with MySQL driver in SQLAlchemy
pymysql.install_as_MySQLdb()

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)
# create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1) # needed for url_for to generate with https

# Configure database connection
# Check if we should use MySQL (set USE_MYSQL=1 in environment)
use_mysql = os.environ.get("USE_MYSQL", "0") == "1"

if use_mysql:
    # Format: mysql+pymysql://<username>:<password>@<host>/<dbname>
    mysql_user = os.environ.get("MYSQL_USER", "root")
    mysql_password = os.environ.get("MYSQL_PASSWORD", "")
    mysql_host = os.environ.get("MYSQL_HOST", "localhost")
    mysql_db = os.environ.get("MYSQL_DB", "hrms_db")
    db_uri = f"mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}/{mysql_db}"
    logging.info(f"Using MySQL database: {mysql_db}")
else:
    # Use SQLite by default (easier to set up)
    db_uri = os.environ.get("DATABASE_URL", "sqlite:///hrms.db") 
    logging.info("Using SQLite database")

app.config["SQLALCHEMY_DATABASE_URI"] = db_uri

app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# initialize the app with the extension, flask-sqlalchemy >= 3.0.x
db.init_app(app)

# Flask-Login configuration
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'info'

with app.app_context():
    # Make sure to import the models here or their tables won't be created
    import models  # noqa: F401
    from routes import register_routes
    
    db.create_all()
    register_routes(app)
    
    # Create default admin if not exists
    from models import User
    from werkzeug.security import generate_password_hash
    
    admin = User.query.filter_by(role='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@hrms.com',
            password_hash=generate_password_hash('admin123'),
            role='admin',
            first_name='Admin',
            last_name='User',
            phone='1234567890',
            department='HR',
            designation='HR Manager',
            is_active=True
        )
        db.session.add(admin)
        db.session.commit()
        logging.info("Default admin created")

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))
