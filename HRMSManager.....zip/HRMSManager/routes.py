from flask import render_template, redirect, url_for, flash, request, jsonify, abort, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime, timedelta, date
import csv
import io
from functools import wraps

from app import db
from models import User, Attendance, Leave, Holiday, Announcement, LeaveBalance, LeavePolicy
from forms import (LoginForm, RegisterForm, EmployeeForm, ProfileForm, PasswordChangeForm, 
                  LeaveForm, LeaveActionForm, AttendanceForm, HolidayForm, 
                  AnnouncementForm, LeavePolicyForm, ReportForm)
from utils import get_client_ip, is_weekend, get_leave_balance, create_attendance_chart_data

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def register_routes(app):
    # Context processor to add common variables to all templates
    @app.context_processor
    def inject_now():
        return {'now': datetime.now()}
    
    # Authentication routes
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            if current_user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('employee_dashboard'))
        return render_template('index.html')
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user and check_password_hash(user.password_hash, form.password.data):
                login_user(user, remember=form.remember_me.data)
                next_page = request.args.get('next')
                return redirect(next_page or url_for('index'))
            else:
                flash('Invalid username or password', 'danger')
        
        return render_template('login.html', form=form)
    
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        
        form = RegisterForm()
        if form.validate_on_submit():
            user = User(
                username=form.username.data,
                email=form.email.data,
                password_hash=generate_password_hash(form.password.data),
                role='employee',
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                joining_date=date.today(),
                is_active=True
            )
            db.session.add(user)
            db.session.commit()
            flash('Your account has been created! You can now log in.', 'success')
            return redirect(url_for('login'))
        
        return render_template('register.html', form=form)
        
    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('index'))
    
    # Employee dashboard
    @app.route('/employee/dashboard')
    @login_required
    def employee_dashboard():
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        
        # Get today's attendance
        today = date.today()
        attendance = Attendance.query.filter_by(user_id=current_user.id, date=today).first()
        
        # Get announcements
        announcements = Announcement.query.filter_by(is_active=True).order_by(Announcement.created_at.desc()).limit(5).all()
        
        # Get leave requests
        leaves = Leave.query.filter_by(user_id=current_user.id).order_by(Leave.applied_on.desc()).limit(5).all()
        
        # Get upcoming holidays
        upcoming_holidays = Holiday.query.filter(Holiday.date >= today).order_by(Holiday.date).limit(5).all()
        
        # Get leave balance
        leave_balance = get_leave_balance(current_user.id)
        
        return render_template('employee/dashboard.html', 
                              attendance=attendance, 
                              announcements=announcements, 
                              leaves=leaves,
                              upcoming_holidays=upcoming_holidays,
                              leave_balance=leave_balance)
    
    # Admin dashboard
    @app.route('/admin/dashboard')
    @login_required
    @admin_required
    def admin_dashboard():
        # Count employees
        total_employees = User.query.filter_by(role='employee').count()
        
        # Count active leaves
        pending_leaves = Leave.query.filter_by(status='pending').count()
        
        # Get today's attendance stats
        today = date.today()
        present_today = Attendance.query.filter_by(date=today, status='present').count()
        absent_today = Attendance.query.filter_by(date=today, status='absent').count()
        
        # Get announcements
        announcements = Announcement.query.order_by(Announcement.created_at.desc()).limit(5).all()
        
        # Get leave requests
        leaves = Leave.query.filter_by(status='pending').order_by(Leave.applied_on).limit(5).all()
        
        # Get attendance chart data
        attendance_chart_data = create_attendance_chart_data()
        
        return render_template('admin/dashboard.html',
                              total_employees=total_employees,
                              pending_leaves=pending_leaves,
                              present_today=present_today,
                              absent_today=absent_today,
                              announcements=announcements,
                              leaves=leaves,
                              attendance_chart_data=attendance_chart_data)
    
    # Employee profile routes
    @app.route('/employee/profile', methods=['GET', 'POST'])
    @login_required
    def employee_profile():
        form = ProfileForm(obj=current_user)
        
        if form.validate_on_submit():
            current_user.first_name = form.first_name.data
            current_user.last_name = form.last_name.data
            current_user.email = form.email.data
            current_user.phone = form.phone.data
            
            db.session.commit()
            flash('Profile updated successfully', 'success')
            return redirect(url_for('employee_profile'))
        
        return render_template('employee/profile.html', form=form)
    
    @app.route('/employee/change-password', methods=['GET', 'POST'])
    @login_required
    def change_password():
        form = PasswordChangeForm()
        
        if form.validate_on_submit():
            if check_password_hash(current_user.password_hash, form.current_password.data):
                current_user.password_hash = generate_password_hash(form.new_password.data)
                db.session.commit()
                flash('Your password has been updated', 'success')
                return redirect(url_for('employee_profile'))
            else:
                flash('Incorrect current password', 'danger')
        
        return render_template('employee/profile.html', form=form, password_form=True)
    
    # Attendance routes
    @app.route('/attendance/check-in', methods=['POST'])
    @login_required
    def check_in():
        today = date.today()
        
        # Check if already checked in
        attendance = Attendance.query.filter_by(user_id=current_user.id, date=today).first()
        
        if attendance and attendance.check_in:
            flash('You have already checked in today', 'warning')
        else:
            if not attendance:
                attendance = Attendance(
                    user_id=current_user.id,
                    date=today,
                    status='present',
                    ip_address=get_client_ip()
                )
                db.session.add(attendance)
            
            attendance.check_in = datetime.now()
            db.session.commit()
            flash('Check-in successful', 'success')
        
        return redirect(url_for('employee_dashboard'))
    
    @app.route('/attendance/check-out', methods=['POST'])
    @login_required
    def check_out():
        today = date.today()
        
        # Find today's attendance
        attendance = Attendance.query.filter_by(user_id=current_user.id, date=today).first()
        
        if not attendance or not attendance.check_in:
            flash('You need to check in first', 'warning')
        elif attendance.check_out:
            flash('You have already checked out today', 'warning')
        else:
            attendance.check_out = datetime.now()
            db.session.commit()
            flash('Check-out successful', 'success')
        
        return redirect(url_for('employee_dashboard'))
    
    @app.route('/attendance/break-start', methods=['POST'])
    @login_required
    def break_start():
        today = date.today()
        
        # Find today's attendance
        attendance = Attendance.query.filter_by(user_id=current_user.id, date=today).first()
        
        if not attendance or not attendance.check_in:
            flash('You need to check in first', 'warning')
        elif attendance.check_out:
            flash('You have already checked out today', 'warning')
        elif attendance.break_start and not attendance.break_end:
            flash('You need to end your previous break first', 'warning')
        else:
            attendance.break_start = datetime.now()
            db.session.commit()
            flash('Break started', 'success')
        
        return redirect(url_for('employee_dashboard'))
    
    @app.route('/attendance/break-end', methods=['POST'])
    @login_required
    def break_end():
        today = date.today()
        
        # Find today's attendance
        attendance = Attendance.query.filter_by(user_id=current_user.id, date=today).first()
        
        if not attendance or not attendance.break_start:
            flash('You need to start a break first', 'warning')
        elif attendance.break_end:
            flash('You have already ended your break', 'warning')
        else:
            attendance.break_end = datetime.now()
            db.session.commit()
            flash('Break ended', 'success')
        
        return redirect(url_for('employee_dashboard'))
    
    @app.route('/employee/attendance')
    @login_required
    def employee_attendance():
        month = request.args.get('month', datetime.now().strftime('%Y-%m'))
        year, month = map(int, month.split('-'))
        
        month_start = date(year, month, 1)
        if month == 12:
            month_end = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            month_end = date(year, month + 1, 1) - timedelta(days=1)
        
        # Get all attendance records for the month
        attendances = Attendance.query.filter(
            Attendance.user_id == current_user.id,
            Attendance.date >= month_start,
            Attendance.date <= month_end
        ).all()
        
        # Create a dict to easily look up attendance by date
        attendance_dict = {a.date: a for a in attendances}
        
        # Generate calendar data
        calendar_data = []
        current_date = month_start
        
        while current_date <= month_end:
            is_weekend_day = is_weekend(current_date)
            attendance = attendance_dict.get(current_date)
            
            calendar_data.append({
                'date': current_date,
                'is_weekend': is_weekend_day,
                'attendance': attendance
            })
            
            current_date += timedelta(days=1)
        
        # Calculate attendance summary
        total_working_days = sum(1 for day in calendar_data if not day['is_weekend'])
        present_days = sum(1 for day in calendar_data if not day['is_weekend'] and day.get('attendance') and day['attendance'].status == 'present')
        absent_days = sum(1 for day in calendar_data if not day['is_weekend'] and (not day.get('attendance') or day['attendance'].status == 'absent'))
        
        return render_template('employee/attendance.html', 
                              calendar_data=calendar_data,
                              month=f"{year}-{month:02d}",
                              total_working_days=total_working_days,
                              present_days=present_days,
                              absent_days=absent_days)
    
    # Leave management routes
    @app.route('/employee/leave', methods=['GET', 'POST'])
    @login_required
    def employee_leave():
        form = LeaveForm()
        
        if form.validate_on_submit():
            leave = Leave(
                user_id=current_user.id,
                start_date=form.start_date.data,
                end_date=form.end_date.data,
                leave_type=form.leave_type.data,
                reason=form.reason.data,
                status='pending',
                applied_on=datetime.now()
            )
            db.session.add(leave)
            db.session.commit()
            flash('Leave request submitted successfully', 'success')
            return redirect(url_for('employee_leave'))
        
        # Get all leave requests
        leaves = Leave.query.filter_by(user_id=current_user.id).order_by(Leave.applied_on.desc()).all()
        
        # Get leave balance
        leave_balance = get_leave_balance(current_user.id)
        
        return render_template('employee/leave.html', form=form, leaves=leaves, leave_balance=leave_balance)
    
    # Admin routes
    @app.route('/admin/employees', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_employees():
        form = EmployeeForm()
        
        if form.validate_on_submit():
            user = User(
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                username=form.username.data,
                email=form.email.data,
                password_hash=generate_password_hash(form.password.data),
                role=form.role.data,
                phone=form.phone.data,
                department=form.department.data,
                designation=form.designation.data,
                joining_date=form.joining_date.data,
                is_active=form.is_active.data
            )
            db.session.add(user)
            db.session.commit()
            
            # Create leave balance for new employee
            current_year = datetime.now().year
            leave_policy = LeavePolicy.query.filter_by(is_active=True).first()
            
            if leave_policy:
                leave_balance = LeaveBalance(
                    user_id=user.id,
                    year=current_year,
                    casual_leave=leave_policy.casual_leave,
                    sick_leave=leave_policy.sick_leave,
                    paid_leave=leave_policy.paid_leave
                )
                db.session.add(leave_balance)
                db.session.commit()
            
            flash('Employee added successfully', 'success')
            return redirect(url_for('admin_employees'))
        
        employees = User.query.order_by(User.first_name).all()
        return render_template('admin/employees.html', form=form, employees=employees)
    
    @app.route('/admin/employee/<int:id>/edit', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_edit_employee(id):
        user = User.query.get_or_404(id)
        form = EmployeeForm(obj=user)
        
        if request.method == 'POST':
            if form.validate_on_submit():
                form.populate_obj(user)
                
                if form.password.data:
                    user.password_hash = generate_password_hash(form.password.data)
                
                db.session.commit()
                flash('Employee updated successfully', 'success')
                return redirect(url_for('admin_employees'))
        
        return render_template('admin/employees.html', form=form, employees=User.query.all(), edit=True)
    
    @app.route('/admin/employee/<int:id>/delete', methods=['POST'])
    @login_required
    @admin_required
    def admin_delete_employee(id):
        if id == current_user.id:
            flash('You cannot delete your own account', 'danger')
            return redirect(url_for('admin_employees'))
        
        user = User.query.get_or_404(id)
        db.session.delete(user)
        db.session.commit()
        flash('Employee deleted successfully', 'success')
        return redirect(url_for('admin_employees'))
    
    @app.route('/admin/attendance', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_attendance():
        form = AttendanceForm()
        form.user_id.choices = [(u.id, u.full_name()) for u in User.query.filter_by(role='employee').order_by(User.first_name)]
        
        if form.validate_on_submit():
            # Check if attendance record already exists
            attendance = Attendance.query.filter_by(
                user_id=form.user_id.data,
                date=form.date.data
            ).first()
            
            if not attendance:
                attendance = Attendance(
                    user_id=form.user_id.data,
                    date=form.date.data,
                    status=form.status.data,
                    comments=form.comments.data
                )
                db.session.add(attendance)
            else:
                attendance.status = form.status.data
                attendance.comments = form.comments.data
            
            db.session.commit()
            flash('Attendance recorded successfully', 'success')
            return redirect(url_for('admin_attendance'))
        
        # Get filter parameters
        date_filter = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
        user_filter = request.args.get('user_id')
        
        # Get attendance records
        query = Attendance.query.join(User).filter(Attendance.date == date_filter)
        
        if user_filter:
            query = query.filter(Attendance.user_id == user_filter)
        
        attendances = query.all()
        
        # Get employees for filter dropdown
        employees = User.query.filter_by(role='employee').order_by(User.first_name).all()
        
        return render_template('admin/attendance.html', 
                              form=form, 
                              attendances=attendances, 
                              employees=employees,
                              date_filter=date_filter,
                              user_filter=user_filter)
    
    @app.route('/admin/leave', methods=['GET'])
    @login_required
    @admin_required
    def admin_leave():
        status_filter = request.args.get('status', 'pending')
        
        # Get leave requests based on status filter
        if status_filter == 'all':
            leaves = Leave.query.order_by(Leave.applied_on.desc()).all()
        else:
            leaves = Leave.query.filter_by(status=status_filter).order_by(Leave.applied_on.desc()).all()
        
        return render_template('admin/leave.html', leaves=leaves, status_filter=status_filter)
    
    @app.route('/admin/leave/<int:id>/action', methods=['POST'])
    @login_required
    @admin_required
    def admin_leave_action(id):
        leave = Leave.query.get_or_404(id)
        
        action = request.form.get('action')
        comments = request.form.get('comments', '')
        
        if action not in ['approved', 'rejected']:
            flash('Invalid action', 'danger')
            return redirect(url_for('admin_leave'))
        
        leave.status = action
        leave.approved_by = current_user.id
        leave.comments = comments
        
        # Update leave balance if approved
        if action == 'approved':
            leave_balance = LeaveBalance.query.filter_by(
                user_id=leave.user_id,
                year=leave.start_date.year
            ).first()
            
            if leave_balance:
                leave_days = (leave.end_date - leave.start_date).days + 1
                
                if leave.leave_type == 'casual':
                    leave_balance.casual_leave -= leave_days
                elif leave.leave_type == 'sick':
                    leave_balance.sick_leave -= leave_days
                elif leave.leave_type == 'paid':
                    leave_balance.paid_leave -= leave_days
        
        db.session.commit()
        flash(f'Leave request {action}', 'success')
        return redirect(url_for('admin_leave'))
    
    @app.route('/admin/holidays', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_holidays():
        form = HolidayForm()
        
        if form.validate_on_submit():
            holiday = Holiday(
                name=form.name.data,
                date=form.date.data,
                description=form.description.data
            )
            db.session.add(holiday)
            db.session.commit()
            flash('Holiday added successfully', 'success')
            return redirect(url_for('admin_holidays'))
        
        # Get filter parameters
        year_filter = request.args.get('year', datetime.now().year)
        
        # Get holidays for the selected year
        holidays = Holiday.query.filter(db.extract('year', Holiday.date) == year_filter).order_by(Holiday.date).all()
        
        return render_template('admin/holidays.html', form=form, holidays=holidays, year_filter=year_filter)
    
    @app.route('/admin/holiday/<int:id>/delete', methods=['POST'])
    @login_required
    @admin_required
    def admin_delete_holiday(id):
        holiday = Holiday.query.get_or_404(id)
        db.session.delete(holiday)
        db.session.commit()
        flash('Holiday deleted successfully', 'success')
        return redirect(url_for('admin_holidays'))
    
    @app.route('/admin/announcements', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_announcements():
        form = AnnouncementForm()
        
        if form.validate_on_submit():
            announcement = Announcement(
                title=form.title.data,
                content=form.content.data,
                created_by=current_user.id,
                is_active=form.is_active.data
            )
            db.session.add(announcement)
            db.session.commit()
            flash('Announcement created successfully', 'success')
            return redirect(url_for('admin_announcements'))
        
        announcements = Announcement.query.order_by(Announcement.created_at.desc()).all()
        return render_template('admin/announcements.html', form=form, announcements=announcements)
    
    @app.route('/admin/announcement/<int:id>/delete', methods=['POST'])
    @login_required
    @admin_required
    def admin_delete_announcement(id):
        announcement = Announcement.query.get_or_404(id)
        db.session.delete(announcement)
        db.session.commit()
        flash('Announcement deleted successfully', 'success')
        return redirect(url_for('admin_announcements'))
    
    @app.route('/admin/reports', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_reports():
        form = ReportForm()
        
        # Get unique departments for the dropdown
        departments = db.session.query(User.department).distinct().all()
        form.department.choices = [('all', 'All Departments')] + [(d[0], d[0]) for d in departments if d[0]]
        
        report_data = None
        export_url = None
        
        if form.validate_on_submit():
            report_type = form.report_type.data
            start_date = form.start_date.data
            end_date = form.end_date.data
            department = form.department.data
            
            if report_type == 'attendance':
                # Generate attendance report
                query = db.session.query(
                    User.id, User.first_name, User.last_name, User.department,
                    Attendance.date, Attendance.status, Attendance.check_in, Attendance.check_out
                ).join(Attendance, User.id == Attendance.user_id)
                
                if department != 'all':
                    query = query.filter(User.department == department)
                
                query = query.filter(
                    Attendance.date >= start_date,
                    Attendance.date <= end_date
                ).order_by(User.first_name, Attendance.date)
                
                report_data = query.all()
                
                # Store parameters in session for export
                session['report_params'] = {
                    'type': 'attendance',
                    'start_date': start_date.isoformat(),
                    'end_date': end_date.isoformat(),
                    'department': department
                }
                
                export_url = url_for('export_report')
                
            elif report_type == 'leave':
                # Generate leave report
                query = db.session.query(
                    User.id, User.first_name, User.last_name, User.department,
                    Leave.start_date, Leave.end_date, Leave.leave_type, Leave.status
                ).join(Leave, User.id == Leave.user_id)
                
                if department != 'all':
                    query = query.filter(User.department == department)
                
                query = query.filter(
                    db.or_(
                        db.and_(Leave.start_date >= start_date, Leave.start_date <= end_date),
                        db.and_(Leave.end_date >= start_date, Leave.end_date <= end_date)
                    )
                ).order_by(User.first_name, Leave.start_date)
                
                report_data = query.all()
                
                # Store parameters in session for export
                session['report_params'] = {
                    'type': 'leave',
                    'start_date': start_date.isoformat(),
                    'end_date': end_date.isoformat(),
                    'department': department
                }
                
                export_url = url_for('export_report')
        
        return render_template('admin/reports.html', form=form, report_data=report_data, export_url=export_url)
    
    @app.route('/admin/export-report')
    @login_required
    @admin_required
    def export_report():
        # Get report parameters from session
        report_params = session.get('report_params')
        
        if not report_params:
            flash('No report parameters found', 'danger')
            return redirect(url_for('admin_reports'))
        
        report_type = report_params.get('type')
        start_date = datetime.fromisoformat(report_params.get('start_date')).date()
        end_date = datetime.fromisoformat(report_params.get('end_date')).date()
        department = report_params.get('department')
        
        # Create CSV
        output = io.StringIO()
        writer = csv.writer(output)
        
        if report_type == 'attendance':
            # Write attendance report headers
            writer.writerow(['Employee ID', 'Name', 'Department', 'Date', 'Status', 'Check In', 'Check Out', 'Duration'])
            
            # Get attendance data
            query = db.session.query(
                User.id, User.first_name, User.last_name, User.department,
                Attendance.date, Attendance.status, Attendance.check_in, Attendance.check_out
            ).join(Attendance, User.id == Attendance.user_id)
            
            if department != 'all':
                query = query.filter(User.department == department)
            
            query = query.filter(
                Attendance.date >= start_date,
                Attendance.date <= end_date
            ).order_by(User.first_name, Attendance.date)
            
            for row in query.all():
                user_id, first_name, last_name, dept, date, status, check_in, check_out = row
                
                # Calculate duration
                duration = ''
                if check_in and check_out:
                    total_seconds = (check_out - check_in).total_seconds()
                    hours = total_seconds // 3600
                    minutes = (total_seconds % 3600) // 60
                    duration = f"{int(hours)}h {int(minutes)}m"
                
                writer.writerow([
                    user_id, 
                    f"{first_name} {last_name}", 
                    dept, 
                    date.strftime('%Y-%m-%d'), 
                    status,
                    check_in.strftime('%H:%M:%S') if check_in else '',
                    check_out.strftime('%H:%M:%S') if check_out else '',
                    duration
                ])
            
            filename = f"attendance_report_{start_date}_to_{end_date}.csv"
            
        elif report_type == 'leave':
            # Write leave report headers
            writer.writerow(['Employee ID', 'Name', 'Department', 'Start Date', 'End Date', 'Days', 'Leave Type', 'Status'])
            
            # Get leave data
            query = db.session.query(
                User.id, User.first_name, User.last_name, User.department,
                Leave.start_date, Leave.end_date, Leave.leave_type, Leave.status
            ).join(Leave, User.id == Leave.user_id)
            
            if department != 'all':
                query = query.filter(User.department == department)
            
            query = query.filter(
                db.or_(
                    db.and_(Leave.start_date >= start_date, Leave.start_date <= end_date),
                    db.and_(Leave.end_date >= start_date, Leave.end_date <= end_date)
                )
            ).order_by(User.first_name, Leave.start_date)
            
            for row in query.all():
                user_id, first_name, last_name, dept, start, end, leave_type, status = row
                
                # Calculate number of days
                days = (end - start).days + 1
                
                writer.writerow([
                    user_id, 
                    f"{first_name} {last_name}", 
                    dept, 
                    start.strftime('%Y-%m-%d'),
                    end.strftime('%Y-%m-%d'),
                    days,
                    leave_type,
                    status
                ])
            
            filename = f"leave_report_{start_date}_to_{end_date}.csv"
        
        # Rewind the buffer
        output.seek(0)
        
        # Create response with CSV
        response = app.response_class(
            response=output.getvalue(),
            content_type='text/csv',
            headers={'Content-Disposition': f'attachment; filename={filename}'}
        )
        
        return response
    
    @app.route('/admin/settings', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_settings():
        form = LeavePolicyForm()
        
        if form.validate_on_submit():
            # Deactivate all existing policies
            LeavePolicy.query.update({'is_active': False})
            
            # Create new policy
            policy = LeavePolicy(
                name=form.name.data,
                casual_leave=form.casual_leave.data,
                sick_leave=form.sick_leave.data,
                paid_leave=form.paid_leave.data,
                description=form.description.data,
                is_active=True
            )
            db.session.add(policy)
            db.session.commit()
            flash('Leave policy updated successfully', 'success')
            return redirect(url_for('admin_settings'))
        
        # Get current policy
        current_policy = LeavePolicy.query.filter_by(is_active=True).first()
        if current_policy:
            form = LeavePolicyForm(obj=current_policy)
        
        return render_template('admin/settings.html', form=form, current_policy=current_policy)
