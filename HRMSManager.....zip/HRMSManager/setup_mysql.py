#!/usr/bin/env python
"""
MySQL setup script for HRMS application.

This script sets up a MySQL database for the HRMS application.
It creates the database if it doesn't exist and provides instructions
for switching from SQLite to MySQL.
"""

import os
import sys
import subprocess
import time
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(levelname)s - %(message)s')

# MySQL configuration
MYSQL_USER = os.environ.get("MYSQL_USER", "root")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
MYSQL_DB = os.environ.get("MYSQL_DB", "hrms_db")

def check_mysql_installed():
    """Check if MySQL client is installed."""
    try:
        # Try to run 'mysql --version' to check if MySQL client is installed
        result = subprocess.run(
            ['which', 'mysql'], 
            capture_output=True, 
            text=True
        )
        
        return result.returncode == 0
    except Exception as e:
        logging.error(f"Error checking MySQL installation: {e}")
        return False

def create_mysql_database():
    """Create MySQL database if it doesn't exist."""
    try:
        # Create database command
        cmd = [
            'mysql',
            '--host=' + MYSQL_HOST,
        ]
        
        # Add credentials if provided
        if MYSQL_USER:
            cmd.append('--user=' + MYSQL_USER)
        if MYSQL_PASSWORD:
            cmd.append('--password=' + MYSQL_PASSWORD)
            
        # Create database SQL
        sql = f"CREATE DATABASE IF NOT EXISTS {MYSQL_DB} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
        
        # Execute command
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        stdout, stderr = process.communicate(sql)
        
        if process.returncode != 0:
            logging.error(f"Error creating database: {stderr}")
            return False
        
        logging.info(f"Database '{MYSQL_DB}' created or already exists.")
        return True
    except Exception as e:
        logging.error(f"Exception creating database: {e}")
        return False

def main():
    """Main function."""
    logging.info("Starting MySQL setup for HRMS application...")
    
    # Check if MySQL is installed
    if not check_mysql_installed():
        logging.error("MySQL client is not installed. Please install MySQL first.")
        print("\nTo install MySQL, you can run:")
        print("  apt-get install mysql-server")
        return False
    
    # Create MySQL database
    if not create_mysql_database():
        return False
    
    # Print success message and instructions
    print("\n" + "="*50)
    print("MySQL Setup Completed Successfully!")
    print("="*50)
    print("\nTo use MySQL with HRMS, set the following environment variables:")
    print(f"  export USE_MYSQL=1")
    print(f"  export MYSQL_USER={MYSQL_USER}")
    print(f"  export MYSQL_PASSWORD=your_password")
    print(f"  export MYSQL_HOST={MYSQL_HOST}")
    print(f"  export MYSQL_DB={MYSQL_DB}")
    print("\nOr on Windows:")
    print(f"  set USE_MYSQL=1")
    print(f"  set MYSQL_USER={MYSQL_USER}")
    print(f"  set MYSQL_PASSWORD=your_password")
    print(f"  set MYSQL_HOST={MYSQL_HOST}")
    print(f"  set MYSQL_DB={MYSQL_DB}")
    print("\nThen restart your application.")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)