/**
 * Chart related JavaScript functionality for HRMS dashboards
 */

document.addEventListener('DOMContentLoaded', function() {
    // Attendance overview chart on admin dashboard
    const attendanceChartCanvas = document.getElementById('attendanceChart');
    if (attendanceChartCanvas) {
        // The chart data is passed from the server as a JSON object
        const chartData = JSON.parse(attendanceChartCanvas.getAttribute('data-chart') || '{}');
        
        if (chartData && chartData.dates) {
            new Chart(attendanceChartCanvas.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: chartData.dates,
                    datasets: [
                        {
                            label: 'Present',
                            data: chartData.present,
                            backgroundColor: 'rgba(40, 167, 69, 0.6)',
                            borderColor: 'rgba(40, 167, 69, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Absent',
                            data: chartData.absent,
                            backgroundColor: 'rgba(220, 53, 69, 0.6)',
                            borderColor: 'rgba(220, 53, 69, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top'
                        }
                    }
                }
            });
        }
    }
    
    // Leave statistics chart on admin dashboard
    const leaveChartCanvas = document.getElementById('leaveChart');
    if (leaveChartCanvas) {
        const chartData = JSON.parse(leaveChartCanvas.getAttribute('data-chart') || '{}');
        
        if (chartData && chartData.labels) {
            new Chart(leaveChartCanvas.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        data: chartData.data,
                        backgroundColor: [
                            'rgba(255, 193, 7, 0.8)',  // Casual - warning
                            'rgba(220, 53, 69, 0.8)',  // Sick - danger
                            'rgba(23, 162, 184, 0.8)', // Paid - info
                            'rgba(108, 117, 125, 0.8)' // Unpaid - secondary
                        ],
                        borderColor: [
                            'rgba(255, 193, 7, 1)',
                            'rgba(220, 53, 69, 1)',
                            'rgba(23, 162, 184, 1)',
                            'rgba(108, 117, 125, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
        }
    }
    
    // Department-wise employee distribution chart
    const departmentChartCanvas = document.getElementById('departmentChart');
    if (departmentChartCanvas) {
        const chartData = JSON.parse(departmentChartCanvas.getAttribute('data-chart') || '{}');
        
        if (chartData && chartData.labels) {
            new Chart(departmentChartCanvas.getContext('2d'), {
                type: 'pie',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        data: chartData.data,
                        backgroundColor: [
                            'rgba(0, 123, 255, 0.8)',    // primary
                            'rgba(40, 167, 69, 0.8)',    // success
                            'rgba(255, 193, 7, 0.8)',    // warning
                            'rgba(220, 53, 69, 0.8)',    // danger
                            'rgba(23, 162, 184, 0.8)',   // info
                            'rgba(108, 117, 125, 0.8)',  // secondary
                            'rgba(111, 66, 193, 0.8)',   // purple
                            'rgba(253, 126, 20, 0.8)'    // orange
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
        }
    }
    
    // Monthly attendance trend chart
    const attendanceTrendChartCanvas = document.getElementById('attendanceTrendChart');
    if (attendanceTrendChartCanvas) {
        const chartData = JSON.parse(attendanceTrendChartCanvas.getAttribute('data-chart') || '{}');
        
        if (chartData && chartData.months) {
            new Chart(attendanceTrendChartCanvas.getContext('2d'), {
                type: 'line',
                data: {
                    labels: chartData.months,
                    datasets: [
                        {
                            label: 'Present %',
                            data: chartData.present_percentage,
                            borderColor: 'rgba(40, 167, 69, 1)',
                            backgroundColor: 'rgba(40, 167, 69, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Absent %',
                            data: chartData.absent_percentage,
                            borderColor: 'rgba(220, 53, 69, 1)',
                            backgroundColor: 'rgba(220, 53, 69, 0.1)',
                            tension: 0.4,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + context.raw + '%';
                                }
                            }
                        }
                    }
                }
            });
        }
    }
});
