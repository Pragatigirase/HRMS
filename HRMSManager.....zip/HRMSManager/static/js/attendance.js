/**
 * Attendance related JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Month selector on attendance page
    const monthSelector = document.getElementById('month');
    if (monthSelector) {
        monthSelector.addEventListener('change', function() {
            const form = monthSelector.closest('form');
            if (form) {
                form.submit();
            }
        });
    }
    
    // Year selector on holidays page
    const yearSelector = document.getElementById('year');
    if (yearSelector) {
        yearSelector.addEventListener('change', function() {
            const form = yearSelector.closest('form');
            if (form) {
                form.submit();
            }
        });
    }
    
    // Current time display on check-in/check-out page
    const clockElement = document.getElementById('digital-clock');
    if (clockElement) {
        updateClock();
        
        function updateClock() {
            const now = new Date();
            const hours = now.getHours();
            const minutes = now.getMinutes();
            const seconds = now.getSeconds();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            const twelveHour = hours % 12 || 12;
            
            clockElement.textContent = 
                `${twelveHour}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} ${ampm}`;
            
            setTimeout(updateClock, 1000);
        }
    }
    
    // Attendance status indicator in calendar view
    const calendarCells = document.querySelectorAll('.calendar-cell');
    calendarCells.forEach(function(cell) {
        const status = cell.getAttribute('data-status');
        if (status) {
            let bgColor = '';
            switch (status) {
                case 'present':
                    bgColor = 'rgba(40, 167, 69, 0.1)';
                    break;
                case 'absent':
                    bgColor = 'rgba(220, 53, 69, 0.1)';
                    break;
                case 'half-day':
                    bgColor = 'rgba(255, 193, 7, 0.1)';
                    break;
            }
            if (bgColor) {
                cell.style.backgroundColor = bgColor;
            }
        }
    });
    
    // Initialize web camera if available
    const cameraElement = document.getElementById('camera');
    const captureButton = document.getElementById('capture-btn');
    const photoInput = document.getElementById('photo_data');
    
    if (cameraElement && captureButton && photoInput) {
        let stream = null;
        
        // Check if the browser supports getUserMedia
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(function(mediaStream) {
                    stream = mediaStream;
                    cameraElement.srcObject = mediaStream;
                    cameraElement.play();
                    captureButton.disabled = false;
                })
                .catch(function(error) {
                    console.error('Could not access the camera: ', error);
                    document.getElementById('camera-container').innerHTML = 
                        '<div class="alert alert-warning">Camera not available. Please check your camera permissions.</div>';
                });
        } else {
            document.getElementById('camera-container').innerHTML = 
                '<div class="alert alert-warning">Your browser does not support camera access.</div>';
        }
        
        // Capture photo when button is clicked
        captureButton.addEventListener('click', function() {
            const canvas = document.createElement('canvas');
            canvas.width = cameraElement.videoWidth;
            canvas.height = cameraElement.videoHeight;
            canvas.getContext('2d').drawImage(cameraElement, 0, 0);
            
            // Convert canvas to base64 data URL
            const dataURL = canvas.toDataURL('image/png');
            photoInput.value = dataURL;
            
            // Show the captured image
            document.getElementById('captured-image').src = dataURL;
            document.getElementById('captured-image').style.display = 'block';
            
            // Stop the camera
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
            
            // Update button states
            captureButton.disabled = true;
            document.getElementById('recapture-btn').style.display = 'inline-block';
        });
        
        // Recapture button functionality
        const recaptureButton = document.getElementById('recapture-btn');
        if (recaptureButton) {
            recaptureButton.addEventListener('click', function() {
                // Restart the camera
                navigator.mediaDevices.getUserMedia({ video: true })
                    .then(function(mediaStream) {
                        stream = mediaStream;
                        cameraElement.srcObject = mediaStream;
                        cameraElement.play();
                        
                        // Reset form elements
                        photoInput.value = '';
                        document.getElementById('captured-image').style.display = 'none';
                        captureButton.disabled = false;
                        recaptureButton.style.display = 'none';
                    });
            });
        }
    }
    
    // IP Address detection for attendance
    const ipAddressElement = document.getElementById('ip_address');
    if (ipAddressElement) {
        // Use a simple API to get the client's IP address
        fetch('https://api.ipify.org?format=json')
            .then(response => response.json())
            .then(data => {
                ipAddressElement.value = data.ip;
            })
            .catch(error => {
                console.error('Error fetching IP:', error);
                ipAddressElement.value = 'Could not detect IP';
            });
    }
});
