document.addEventListener('DOMContentLoaded', function() {
    // Admin Dashboard Charts
    configureAdminDashboardCharts();
    
    // Employee Dashboard Charts
    configureEmployeeDashboardCharts();
});

// Configure charts for admin dashboard
function configureAdminDashboardCharts() {
    // Attendance Overview Chart
    const attendanceChartEl = document.getElementById('attendanceChart');
    if (attendanceChartEl) {
        const attendanceData = JSON.parse(attendanceChartEl.getAttribute('data-attendance'));
        
        new Chart(attendanceChartEl, {
            type: 'doughnut',
            data: {
                labels: ['Present', 'Absent', 'Half Day', 'On Leave'],
                datasets: [{
                    data: [
                        attendanceData.present || 0,
                        attendanceData.absent || 0,
                        attendanceData.half_day || 0,
                        attendanceData.on_leave || 0
                    ],
                    backgroundColor: [
                        '#28a745', // Green for present
                        '#dc3545', // Red for absent
                        '#ffc107', // Yellow for half day
                        '#17a2b8'  // Cyan for leave
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Monthly Attendance Overview'
                    }
                }
            }
        });
    }
    
    // Department Distribution Chart
    const deptChartEl = document.getElementById('departmentChart');
    if (deptChartEl) {
        const deptData = JSON.parse(deptChartEl.getAttribute('data-departments'));
        
        new Chart(deptChartEl, {
            type: 'bar',
            data: {
                labels: deptData.map(d => d.name),
                datasets: [{
                    label: 'Employees by Department',
                    data: deptData.map(d => d.count),
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    }
    
    // Leave Trends Chart
    const leaveChartEl = document.getElementById('leaveChart');
    if (leaveChartEl) {
        const leaveData = JSON.parse(leaveChartEl.getAttribute('data-leaves'));
        
        new Chart(leaveChartEl, {
            type: 'line',
            data: {
                labels: leaveData.labels,
                datasets: [
                    {
                        label: 'Approved',
                        data: leaveData.approved,
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        fill: true
                    },
                    {
                        label: 'Pending',
                        data: leaveData.pending,
                        borderColor: '#ffc107',
                        backgroundColor: 'rgba(255, 193, 7, 0.1)',
                        fill: true
                    },
                    {
                        label: 'Rejected',
                        data: leaveData.rejected,
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220, 53, 69, 0.1)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    }
}

// Configure charts for employee dashboard
function configureEmployeeDashboardCharts() {
    // Attendance Stats Chart
    const attendanceStatsEl = document.getElementById('attendanceStatsChart');
    if (attendanceStatsEl) {
        const statsData = JSON.parse(attendanceStatsEl.getAttribute('data-stats'));
        
        new Chart(attendanceStatsEl, {
            type: 'doughnut',
            data: {
                labels: ['Present', 'Absent', 'Half Day', 'On Leave'],
                datasets: [{
                    data: [
                        statsData.present || 0,
                        statsData.absent || 0,
                        statsData.half_day || 0,
                        statsData.on_leave || 0
                    ],
                    backgroundColor: [
                        '#28a745', // Green for present
                        '#dc3545', // Red for absent
                        '#ffc107', // Yellow for half day
                        '#17a2b8'  // Cyan for leave
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Monthly Attendance'
                    }
                }
            }
        });
    }
    
    // Leave Balance Chart
    const leaveBalanceEl = document.getElementById('leaveBalanceChart');
    if (leaveBalanceEl) {
        const balanceData = JSON.parse(leaveBalanceEl.getAttribute('data-balance'));
        
        new Chart(leaveBalanceEl, {
            type: 'bar',
            data: {
                labels: balanceData.map(lb => lb.type),
                datasets: [
                    {
                        label: 'Used',
                        data: balanceData.map(lb => lb.used),
                        backgroundColor: 'rgba(220, 53, 69, 0.5)',
                        borderColor: 'rgba(220, 53, 69, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Remaining',
                        data: balanceData.map(lb => lb.balance),
                        backgroundColor: 'rgba(40, 167, 69, 0.5)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        stacked: true
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    }
}
