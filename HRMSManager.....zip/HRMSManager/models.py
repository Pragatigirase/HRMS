from datetime import datetime
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='employee')  # 'admin' or 'employee'
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    department = db.Column(db.String(50))
    designation = db.Column(db.String(50))
    joining_date = db.Column(db.Date, default=datetime.now().date)
    profile_pic_url = db.Column(db.String(255), default='https://via.placeholder.com/150')
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    attendances = db.relationship('Attendance', backref='user', lazy=True)
    leaves = db.relationship('Leave', foreign_keys='Leave.user_id', backref='user', lazy=True)
    
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def __repr__(self):
        return f'<User {self.username}>'


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.Date, default=datetime.now().date)
    check_in = db.Column(db.DateTime, nullable=True)
    check_out = db.Column(db.DateTime, nullable=True)
    break_start = db.Column(db.DateTime, nullable=True)
    break_end = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default='present')  # 'present', 'absent', 'half-day'
    ip_address = db.Column(db.String(50), nullable=True)
    photo_url = db.Column(db.String(255), nullable=True)
    comments = db.Column(db.Text, nullable=True)
    
    def __repr__(self):
        return f'<Attendance {self.user_id} {self.date}>'
    
    def duration(self):
        if self.check_in and self.check_out:
            total_seconds = (self.check_out - self.check_in).total_seconds()
            if self.break_start and self.break_end:
                break_seconds = (self.break_end - self.break_start).total_seconds()
                total_seconds -= break_seconds
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return f"{int(hours)}h {int(minutes)}m"
        return "N/A"


class Leave(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    leave_type = db.Column(db.String(20), nullable=False)  # 'casual', 'sick', 'paid', 'unpaid'
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'approved', 'rejected'
    applied_on = db.Column(db.DateTime, default=datetime.now)
    approved_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    comments = db.Column(db.Text, nullable=True)
    
    approver = db.relationship('User', foreign_keys=[approved_by])
    
    def __repr__(self):
        return f'<Leave {self.user_id} {self.start_date} to {self.end_date}>'
    
    def days(self):
        delta = self.end_date - self.start_date
        return delta.days + 1


class Holiday(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    def __repr__(self):
        return f'<Holiday {self.name} {self.date}>'


class Announcement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    
    creator = db.relationship('User', foreign_keys=[created_by])
    
    def __repr__(self):
        return f'<Announcement {self.title}>'


class LeaveBalance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    casual_leave = db.Column(db.Integer, default=0)
    sick_leave = db.Column(db.Integer, default=0)
    paid_leave = db.Column(db.Integer, default=0)
    
    user = db.relationship('User', backref='leave_balances')
    
    def __repr__(self):
        return f'<LeaveBalance {self.user_id} {self.year}>'


class LeavePolicy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    casual_leave = db.Column(db.Integer, default=0)
    sick_leave = db.Column(db.Integer, default=0)
    paid_leave = db.Column(db.Integer, default=0)
    description = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<LeavePolicy {self.name}>'
