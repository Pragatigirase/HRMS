from datetime import datetime, timedelta, date
from flask import request
from models import User, Attendance, Leave, LeaveBalance

def get_client_ip():
    """Get the client's IP address from the request."""
    if request.environ.get('HTTP_X_FORWARDED_FOR'):
        return request.environ['HTTP_X_FORWARDED_FOR']
    return request.environ.get('REMOTE_ADDR', '')

def is_weekend(check_date):
    """Check if a date is a weekend (Saturday or Sunday)."""
    return check_date.weekday() >= 5  # 5 = Saturday, 6 = Sunday

def get_leave_balance(user_id):
    """Get leave balance for a user."""
    current_year = datetime.now().year
    leave_balance = LeaveBalance.query.filter_by(user_id=user_id, year=current_year).first()
    
    if not leave_balance:
        # Return default balance if not found
        return {
            'casual_leave': 0,
            'sick_leave': 0,
            'paid_leave': 0
        }
    
    return {
        'casual_leave': leave_balance.casual_leave,
        'sick_leave': leave_balance.sick_leave,
        'paid_leave': leave_balance.paid_leave
    }

def create_attendance_chart_data():
    """Create data for the attendance chart on the admin dashboard."""
    today = date.today()
    
    # Get data for the past 30 days
    start_date = today - timedelta(days=30)
    end_date = today
    
    # Initialize data arrays
    dates = []
    present_counts = []
    absent_counts = []
    
    current_date = start_date
    while current_date <= end_date:
        if not is_weekend(current_date):
            # Skip weekends
            dates.append(current_date.strftime('%Y-%m-%d'))
            
            # Count present employees
            present_count = Attendance.query.filter_by(
                date=current_date,
                status='present'
            ).count()
            present_counts.append(present_count)
            
            # Count absent employees
            total_employees = User.query.filter_by(role='employee', is_active=True).count()
            absent_count = total_employees - present_count
            absent_counts.append(absent_count if absent_count > 0 else 0)
        
        current_date += timedelta(days=1)
    
    return {
        'dates': dates,
        'present': present_counts,
        'absent': absent_counts
    }

def calculate_leave_days(start_date, end_date):
    """Calculate the number of working days between two dates."""
    days = 0
    current_date = start_date
    
    while current_date <= end_date:
        if not is_weekend(current_date):
            days += 1
        current_date += timedelta(days=1)
    
    return days
